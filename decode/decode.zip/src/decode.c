#include "../include/rtklib.h"
#define RTCM3PREAMB 0xD3        /* rtcm ver.3 frame preamble */


static char* obscodes[] = {       /* observation code strings */

    ""  ,"1C","1P","1W","1Y", "1M","1N","1S","1L","1E", /*  0- 9 */
    "1A","1B","1X","1Z","2C", "2D","2S","2L","2X","2P", /* 10-19 */
    "2W","2Y","2M","2N","5I", "5Q","5X","7I","7Q","7X", /* 20-29 */
    "6A","6B","6C","6X","6Z", "6S","6L","8L","8Q","8X", /* 30-39 */
    "2I","2Q","6I","6Q","3I", "3Q","3X","1I","1Q","5A", /* 40-49 */
    "5B","5C","9A","9B","9C", "9X","1D","5D","5P","5Z", /* 50-59 */
    "6E","7D","7P","7Z","8D", "8P","4A","4B","4X",""    /* 60-69 */
};

/* Return frequency values, ranging from 1 to 5. 0 indicates an exception */
static int getfreqnum(int sat, int code) {
    if (sat <= 0 || sat > MAXSAT || code <= 0 || code > MAXCODE) return 0;
    int sys = satsys(sat, NULL);
    int freq = atoi(obscodes[code]);
    switch (sys)
    {
    case SYS_GPS:
        switch (freq)
        {
        case 1:return 1;
        case 2:return 2;
        case 5:return 3;
        default:
            return 0;
        }
    case SYS_GLO:
        if (freq <= 3) return freq;
        else return 0;
    case SYS_CMP:
        switch (freq)
        {
        case 2:return 1;
        case 5:return 2;
        case 6:return 3;
        case 1:return 4;
        case 7:
            if (obscodes[code] == "7I" || obscodes[code] == "7Q" || obscodes[code] == "7X") return 2;
            if (obscodes[code] == "7D" || obscodes[code] == "7P" || obscodes[code] == "7Z") return 5;
            return 0;
        default:
            return 0;
        }
    case SYS_GAL:
        switch (freq)
        {
        case 1:return 1;
        case 5:return 2;
        case 7:return 3;
        case 8:return 4;
        case 6:return 5;
        default:
            return 0;
        }
    default:
        return 0;
    }
}

/* Return code priority. The value ranges from 1 to 8. 0 indicates an exception*/
static int mess_code_pri(int sys,uint8_t code) {
    char sig[3] = { 0 }; 
    strncpy(sig, obscodes[code], 2);
    switch (sys)
    {
    case SYS_GPS:
        if (!strcmp(sig, "1C") || !strcmp(sig, "2P") || !strcmp(sig, "5I")) return 1;
        if (!strcmp(sig, "1P") || !strcmp(sig, "2S") || !strcmp(sig, "5Q")) return 2;
        if (!strcmp(sig, "1X") || !strcmp(sig, "2L") || !strcmp(sig, "5X")) return 3;
        if (!strcmp(sig, "1W") || !strcmp(sig, "2X")) return 4;
        if (!strcmp(sig, "1N") || !strcmp(sig, "2W")) return 5;
        if (!strcmp(sig, "1S") || !strcmp(sig, "2N")) return 6;
        if (!strcmp(sig, "1L") || !strcmp(sig, "2D")) return 7;
        if (!strcmp(sig, "2C")) return 8;
        return 0;
    case SYS_CMP:
        switch (sig[1])
        {
        case 'I':return 1;
        case 'D':return 1;
        case 'Q':return 2;
        case 'P':return 2;
        case 'X':return 3;
        case 'Z':return 3;
        default:
            return 0;
        }
    case SYS_GLO:
        if (!strcmp(sig, "1C") || !strcmp(sig, "2C") || !strcmp(sig, "3I")) return 1;
        if (!strcmp(sig, "1P") || !strcmp(sig, "2P") || !strcmp(sig, "3Q")) return 2;
        if (!strcmp(sig, "3X")) return 3;
        return 0;
    case SYS_GAL:
        switch (sig[1])
        {
        case 'I':return 1;
        case 'B':return 1;
        case 'C':return 2;
        case 'Q':return 2;
        case 'X':return 3;
        default:
            break;
        }
        return 0;
    default:
        return 0;
    }
}

static char getsysname(int sys) {
    switch (sys)
    {
    case SYS_GPS:return 'G';
    case SYS_GLO:return 'R';
    case SYS_GAL:return 'E';
    case SYS_CMP:return 'C';
    default:
        return ' ';
    }
}

extern uint8_t* readHexFile(const char* filename, int* dataSize) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        perror("�޷����ļ�");
        return NULL;
    }

    size_t maxSize = 1024; 
    uint8_t* data = (uint8_t*)malloc(maxSize * sizeof(uint8_t));
    if (data == NULL) {
        fclose(file);
        return NULL;
    }

    size_t count = 0;
    unsigned int value;

    while (fscanf(file, "%2x", &value) == 1) {
        if (count >= maxSize) {
            maxSize *= 2;
            data = (uint8_t*)realloc(data, maxSize * sizeof(uint8_t));
            if (data == NULL) {
                fclose(file);
                return NULL;
            }
        }
        data[count++] = (uint8_t)value;
    }

    fclose(file);

    *dataSize = count;
    return data;
}

/* return phase shift by code (RINEX 3.04 A23) -------------------------*/
static double getshift(obsd_t obs,int idx)
{
    int i, j, sys = satsys(obs.sat, NULL);
    double shift = 0.0;
    uint8_t code = obs.code[idx];
    
    switch (sys)
    {
    case SYS_GPS:
        if (code == CODE_L1S || code == CODE_L1L || code == CODE_L1X || code == CODE_L1P ||
            code == CODE_L1W || code == CODE_L1N) {
            shift = 0.25; /* +1/4 cyc */
        }
        else if (code == CODE_L2C || code == CODE_L2S || code == CODE_L2L ||
            code == CODE_L2X || code == CODE_L5Q) {
            shift = -0.25; /* -1/4 cyc */
        }
        break;
    case SYS_GLO:
        if (code == CODE_L1P || code == CODE_L2P || code == CODE_L3Q) {
            shift = 0.25; /* +1/4 cyc */
        }
        break;
    case SYS_GAL:
        if (code == CODE_L1C) {
            shift = 0.5; /* +1/2 cyc */
        }
        else if (code == CODE_L5Q || code == CODE_L7Q || code == CODE_L8Q) {
            shift = -0.25; /* -1/4 cyc */
        }
        else if (code == CODE_L6C) {
            shift = -0.5; /* -1/2 cyc */
        }
        break;
    case SYS_QZS:
        if (code == CODE_L1S || code == CODE_L1L || code == CODE_L1X) {
            shift = 0.25; /* +1/4 cyc */
        }
        else if (code == CODE_L5Q || code == CODE_L5P) {
            shift = -0.25; /* -1/4 cyc */
        }
        break;
    case SYS_CMP:
        if (code == CODE_L2P || code == CODE_L7Q || code == CODE_L6Q) {
            shift = -0.25; /* -1/4 cyc */
        }
        else if (code == CODE_L1P || code == CODE_L5P || code == CODE_L7P) {
            shift = 0.25; /* +1/4 cyc */
        }
        break;
    default:
        break;
    }
    
    return shift;
}

extern int init_rtcm_res(rtcm_res* rtcm) {
    int i;
    eph_t  eph0 = { 0,-1,-1 };
    geph_t geph0 = { 0,-1 };
    ssr_t ssr0 = { {{0}} };
    obsd_t data0 = { {0} };

    rtcm->type = 0;
    rtcm->staid = 0;
    rtcm->stah = 0;
    rtcm->seqno = 0;
    rtcm->time.time = 0; rtcm->time.sec = 0;
    rtcm->time_s.time = 0; rtcm->time_s.sec = 0;
    rtcm->obsflag = 0;
    rtcm->ephsat = 0;
    rtcm->ephset = 0;
    rtcm->len = 0;
    rtcm->sta.name[0] = rtcm->sta.marker[0] = '\0';
    rtcm->sta.antdes[0] = rtcm->sta.antsno[0] = '\0';
    rtcm->sta.rectype[0] = rtcm->sta.recver[0] = rtcm->sta.recsno[0] = '\0';
    rtcm->sta.antsetup = rtcm->sta.itrf = rtcm->sta.deltype = 0;
    for (i = 0; i < 3; i++) {
        rtcm->sta.pos[i] = rtcm->sta.del[i] = 0.0;
    }
    rtcm->sta.hgt = 0.0;

    rtcm->eph = eph0;
    rtcm->geph = geph0;
    rtcm->dgps = NULL;
    for (i = 0; i < MAXSAT; i++) {
        rtcm->ssr[i] = ssr0;
    }

    rtcm->obs.data = NULL;
    rtcm->obs.n = 0;
    rtcm->obs.nmax = 0;
    if (!(rtcm->obs.data = (obsd_t*)malloc(sizeof(obsd_t) * MAXOBS))) {
        free_rtcmres(rtcm);
        return 0;
    }
    for (i = 0; i < MAXOBS; i++) rtcm->obs.data[i] = data0;

    return 1;
}

extern int input_rtcm3_byte(rtcm_t* rtcm, uint8_t data)
{
    trace(5, "input_rtcm3: data=%02x\n", data);

    /* synchronize frame */
    if (rtcm->nbyte == 0) {
        if (data != RTCM3PREAMB) return 0;
        rtcm->buff[rtcm->nbyte++] = data;
        return 0;
    }
    rtcm->buff[rtcm->nbyte++] = data;

    if (rtcm->nbyte == 3) {
        rtcm->len = getbitu(rtcm->buff, 14, 10) + 3; /* length without parity */
    }
    if (rtcm->nbyte < 3 || rtcm->nbyte < rtcm->len + 3) return 0;
    rtcm->nbyte = 0;

    /* check parity */
    if (rtk_crc24q(rtcm->buff, rtcm->len) != getbitu(rtcm->buff, rtcm->len * 8, 24)) {
        return 0;
    }

    /* decode rtcm3 message */
    return decode_rtcm3(rtcm);
}

extern rtcm_res* decode(uint8_t* byte, int length, int ver,int phshift)
{
    int i, j, data = 0, prn, ret = 0;
    eph_t e0 = { 0 };
    rtcm_res* rtcm_result = (rtcm_res*)malloc(sizeof(rtcm_res));
    if (!init_rtcm_res(rtcm_result)) return NULL;
    rtcm_t* rtcm = (rtcm_t*)malloc(sizeof(rtcm_t));
    if (!init_rtcm(rtcm)) return NULL;
    for (i = 0; i < length; i++) {
        data = byte[i];
        if (ver == 3)
            ret = input_rtcm3_byte(rtcm, (uint8_t)data);
        if (ver == 2)
            ret = input_rtcm2(rtcm, (uint8_t)data);
    }

    rtcm_result->type = rtcm->type;
    rtcm_result->staid = rtcm->staid;
    rtcm_result->stah = rtcm->stah;
    rtcm_result->seqno = rtcm->seqno;
    rtcm_result->time = rtcm->time;
    rtcm_result->time_s = rtcm->time_s;
    rtcm_result->sta = rtcm->sta;
    rtcm_result->dgps = rtcm->dgps;
    rtcm_result->obsflag = rtcm->obsflag;
    rtcm_result->ephsat = rtcm->ephsat;
    rtcm_result->ephset = rtcm->ephset;
    rtcm_result->len = rtcm->len;
    if (ret == 2) {
        if (satsys(rtcm->ephsat, &prn) == SYS_GLO)
            rtcm_result->geph = rtcm->nav.geph[prn - 1];
        else
        {
            if (rtcm->ephset)
                rtcm_result->eph = rtcm->nav.eph[rtcm->ephsat - 1 + MAXSAT];
            else
                rtcm_result->eph = rtcm->nav.eph[rtcm->ephsat - 1];
        }
    }
    else rtcm_result->eph = e0;
    if (rtcm->obs.n) {
        rtcm_result->obs.n = rtcm->obs.n;
        rtcm_result->obs.nmax = rtcm->obs.nmax;
        for (i = 0; i < rtcm->obs.n; i++) {
            rtcm_result->obs.data[i].time = rtcm->obs.data[i].time;
            rtcm_result->obs.data[i].sat = rtcm->obs.data[i].sat;
            rtcm_result->obs.data[i].rcv = rtcm->obs.data[i].rcv;
            for (j = 0; j < NFREQ + NEXOBS; j++) {
                rtcm_result->obs.data[i].SNR[j] = rtcm->obs.data[i].SNR[j];
                rtcm_result->obs.data[i].LLI[j] = rtcm->obs.data[i].LLI[j];
                rtcm_result->obs.data[i].code[j] = rtcm->obs.data[i].code[j];
                if (phshift) {
                    double shift = getshift(rtcm->obs.data[i],j);
                    rtcm_result->obs.data[i].L[j] = rtcm->obs.data[i].L[j] + shift;
                }
                else
                {
                    rtcm_result->obs.data[i].L[j] = rtcm->obs.data[i].L[j];
                }              
                rtcm_result->obs.data[i].P[j] = rtcm->obs.data[i].P[j];
                rtcm_result->obs.data[i].D[j] = rtcm->obs.data[i].D[j];
            }
        }
    }
    free_rtcm(rtcm);
    free(rtcm);

    return rtcm_result;
}

extern rtcm_t* get_rtcm()
{
    rtcm_t* rtcm = (rtcm_t*)malloc(sizeof(rtcm_t));
    if (!init_rtcm(rtcm)) return NULL;
    return rtcm;
}

extern void decode_tr(rtcm_t* rtcm,uint8_t* byte,int tr, int length, int ver)
{
    int i, j, data = 0, prn, ret = 0;
    eph_t e0 = { 0 };
    if (!rtcm) return;

    if (tr) {
        rtcm->time.time = tr;
    }
    for (i = 0; i < length; i++) {
        data = byte[i];
        if (ver == 3)
            ret = input_rtcm3_byte(rtcm, (uint8_t)data);
        if (ver == 2)
            ret = input_rtcm2(rtcm, (uint8_t)data);
    }
}

extern int free_rtcmres(rtcm_res* rtcm) {
    if (rtcm) {
        free(rtcm->obs.data); rtcm->obs.data = NULL; rtcm->obs.n = 0;
        free(rtcm);
        return 1;
    }
    return 0;
}

extern void free_mess(message_sat* mess_sat) {
    if (mess_sat != NULL) {
        if (mess_sat->obs != NULL)
            free(mess_sat->obs);
        free(mess_sat);
    }
}

/**
 * @brief Convert RTCM decoded observations to message format observations.
 *
 * This function converts the observation data decoded from RTCM into the message format.
 *
 * @param[in] rtcm Pointer to the structure containing RTCM decoded observations.
 * @param[out] mess_obs Pointer to the structure where the message format observations will be stored.
 * @return 0 if there are no observations or the message type is not obs,
 *             -1 if the input pointer is invalid,
 *             -2 if memory allocation for mess_obs fails,
 *             others like 9 representing the number of observations.
 */
extern message_sat* obs2message(rtcm_res* rtcm){
    int i, j, freq, f, verify[5], sys, prn;
    if (rtcm->obs.n <= 0) return NULL;
    /* Check input pointer */
    if (rtcm == NULL) return NULL;
    /* Allocate memory and initialize */
    message_sat* mess_sat = (message_sat*)malloc(sizeof(message_sat));
    if (mess_sat == NULL) return NULL;
    mess_sat->obs = (message_obs*)calloc(rtcm->obs.n, sizeof(message_obs));
    /* Memory allocation error */
    if (mess_sat->obs == NULL) return NULL;
    mess_sat->obsnum = rtcm->obs.n;
    time2epoch(rtcm->obs.data[0].time, mess_sat->time);
    for (i = 0; i < rtcm->obs.n; i++) {
        memset(verify, 0, sizeof(verify));
        obsd_t obs = rtcm->obs.data[i];
        sys = satsys(obs.sat, &prn);
        if (!(sys & (SYS_GPS | SYS_GLO | SYS_GAL | SYS_CMP))) continue;
        mess_sat->obs[i].satellitetype=getsysname(sys);
        mess_sat->obs[i].satelliteprn = prn;
        for (j = 0; j < NFREQ + NEXOBS; j++) {
            if (freq=getfreqnum(obs.sat, obs.code[j])) {                
                int inp = 1;               
                f = freq - 1;
                /* The current frequency has data */
                /* data has normal P/L and its code has a higher priority */
                /* In this case, no data substitution is required */
                if (mess_sat->obs[i].flag[f] && verify[f]==1 &&
                    mess_code_pri(sys, obs.code[j])> mess_sat->obs[i].si[f]) {
                    inp = 0;
                }
                /* input data to message */
                if (inp) {
                    mess_sat->obs[i].c[f] = obs.P[j];
                    mess_sat->obs[i].l[f] = obs.L[j];
                    mess_sat->obs[i].cnr[f] = obs.SNR[j] * SNR_UNIT;
                    mess_sat->obs[i].lli[f] = obs.LLI[j] & (LLI_SLIP | LLI_HALFC | LLI_BOCTRK);
                    mess_sat->obs[i].si[f] = mess_code_pri(sys, obs.code[j]);
                    mess_sat->obs[i].flag[f] = 1;
                    /* Judge whether the obs is complete*/
                    verify[f] = !obs.P[j] || !obs.L[j] ? -1 : 1;
                }                                
            }
        }
    }
    return mess_sat;
}